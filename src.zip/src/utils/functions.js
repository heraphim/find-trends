const isObject = (x) => {
  return typeof x === 'object' && !Array.isArray(x) && x !== null;
}

const isString = (s) => {
  return typeof s === 'string' || s instanceof String;
}

function isInt(x) {
  return !isNaN(x) && parseInt(Number(x)) == x && !isNaN(parseInt(x, 10));
}

const isJson = (str) => {
  try {
    JSON.parse(str);
  } catch (err) {
    return false;
  }
  return true;
}

const escapejson = (val) => {
  if (typeof (val) !== 'string') return val;
  val = val.replace(/\\n/g, "\\n")
    .replace(/\\'/g, "\\'")
    .replace(/\\"/g, '\\"')
    .replace(/\\&/g, "\\&")
    .replace(/\\r/g, "\\r")
    .replace(/\\t/g, "\\t")
    .replace(/\\b/g, "\\b")
    .replace(/\\f/g, "\\f");
  try {
    if (!isJson(val)) {
      val = val.replaceAll(`\\"`, `"`);
    }
  } catch {
    return val;
  }
  return val;
}

module.exports = {
  isObject,
  isString,
  isInt,
  isJson,
  escapejson
}