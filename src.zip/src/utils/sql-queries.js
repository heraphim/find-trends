const sqlGroupProcedure = `
  BEGIN
    writeback_insgroup
    (:v_groupid, :v_groupname);
    COMMIT;
  END;
`

const sqlCommentsGroupsProcedure = `
  BEGIN
    inscommentgroup
    (:v_groupid, :v_commentid, :v_security);
    COMMIT;
  END;
`

const sqlDelCommentGroupProcedure = `
  BEGIN
    delCommentGroup
    (:vrel_commentid, :vrel_security);
    COMMIT;
  END;
`

const sqlGroups = (tableName) =>
  `
    SELECT LISTAGG(COMMENT_GROUPS.NAME,', ') WITHIN GROUP(ORDER BY COMMENT_GROUPS.NAME) AS "GROUP NAME"
    FROM ${tableName}
    LEFT JOIN COMMENTS_TO_GROUPS ON COMMENTS_TO_GROUPS.COMMENT_ID = ${tableName}.ID
    LEFT JOIN COMMENT_GROUPS ON COMMENT_GROUPS.ID = COMMENTS_TO_GROUPS.GROUP_ID
    WHERE ${tableName}.ID = :id AND COMMENTS_TO_GROUPS.SECURITY = :security
  `

const sqlGetImageProcedure = {
  c3: `
    BEGIN
      GETIMAGE_C3(:v_imagepath, :v_imagecommentid);
      CHECKGROUPS_C3(:v_imagecommentid, :v_security, :v_commentgroup);
    END;
  `,
  c4: `
    BEGIN
      GETIMAGE_C4(:v_imagepath, :v_imagecommentid);
      CHECKGROUPS_C4(:v_imagecommentid, :v_security, :v_commentgroup);
    END;
  `
}

const sqlEditCommentProcedure = {
  c3: `
    BEGIN
      CHECKGROUPS_C3(:v_commentid, :v_security, :v_commentgroup);
    END;
  `,
  c4: `
    BEGIN
      CHECKGROUPS_C4(:v_commentid, :v_security, :v_commentgroup);
    END;
  `
}

const sqlAddNewColumn = {
  c3: `alter table SECTION_ACCESS_C3 add NTGROUP VARCHAR(255)`,
  c4: `alter table SECTION_ACCESS_C4 add NTGROUP VARCHAR(255)`,
  mpr: `alter table SECTION_ACCESS_MPR add NTGROUP VARCHAR(255)`
}

module.exports = {
  sqlGroupProcedure,
  sqlCommentsGroupsProcedure,
  sqlDelCommentGroupProcedure,
  sqlGroups,
  sqlGetImageProcedure,
  sqlEditCommentProcedure,
  sqlAddNewColumn
};