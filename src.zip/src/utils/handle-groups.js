const oracledb = require('oracledb');
const { sqlGroupProcedure, sqlCommentsGroupsProcedure } = require('./sql-queries');

const insertGroup = async (commentId, group, security, connection) => {
  const result = await connection.execute(sqlGroupProcedure, { v_groupname: group, v_groupid: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER } }, { autoCommit: true });
  return result.outBinds;
}

const assignCommentsToGroup = async (commentId, group, security, connection) => {
  const result = await connection.execute(sqlCommentsGroupsProcedure, { v_groupid: Number(group.v_groupid), v_commentid: Number(commentId), v_security: security }, { autoCommit: true });
  return result;
}

const handleGroups = async (commentId, groups, security, connection) => {
  let tasks = groups.map(group => insertGroup(commentId, group, security, connection));
  try {
    const results = await Promise.all(tasks);
    tasks = results.map(group => assignCommentsToGroup(commentId, group, security, connection));
  } catch (e) {
    console.log('handleGroups error');
    throw new Error(e);
  }
}

module.exports = handleGroups;