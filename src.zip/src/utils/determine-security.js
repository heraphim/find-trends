const determineSecurity = (security) => security || 'mpr';
const c3OrC4 = (security) => security === 'mpr' ? 'c4' : security;
module.exports = {
  determineSecurity,
  c3OrC4
}