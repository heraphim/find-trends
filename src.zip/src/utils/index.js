const { findUserAD, authenticateUserAd } = require('./ad-functions');
const { determineSecurity, c3OrC4 } = require('./determine-security');
const { dummyQlikUser, dummyCheckAuth } = require('./dummy-data');
const { isObject, isString, isInt, isJson, escapejson } = require('./functions');
const getNtName = require('./get-nt-name');
const handleGroups = require('./handle-groups');
const makeSessionFile = require('./make-session-file');
const { sqlGroupProcedure, sqlCommentsGroupsProcedure, sqlDelCommentGroupProcedure, sqlGroups, sqlGetImageProcedure, sqlEditCommentProcedure, sqlAddNewColumn } = require('./sql-queries');

module.exports = {
  findUserAD,
  authenticateUserAd,
  determineSecurity,
  c3OrC4,
  dummyQlikUser,
  dummyCheckAuth,
  isObject,
  isString,
  isInt,
  isJson,
  escapejson,
  getNtName,
  handleGroups,
  makeSessionFile,
  sqlGroupProcedure,
  sqlCommentsGroupsProcedure,
  sqlDelCommentGroupProcedure,
  sqlGroups,
  sqlGetImageProcedure,
  sqlEditCommentProcedure,
  sqlAddNewColumn
}