/* global process */
const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs');
const md5 = require('md5');

const SESSIONS_PATH = process.env.SESSIONS_PATH;

const makeSessionFile = (userId) => {
  return;
  if (!existsSync(SESSIONS_PATH)) {
    mkdirSync(SESSIONS_PATH);
  }
  const userSessionFilePath = SESSIONS_PATH + '/' + md5(userId) + '.json';
  if (!existsSync(userSessionFilePath)) { // create the file to later fill with group data
    const data = JSON.stringify({ userId: userId });
    writeFileSync(userSessionFilePath, data, "utf8");
    console.log('Written file for: ' + userId);
  } else { // check how old is the data to later fill with more recent
    try {
      let userData = readFileSync(userSessionFilePath, 'utf8');
      userData = JSON.parse(userData);
      const TEN_MINUTES = 10 * 60 * 1000;
      if (userData.ldapGroups && userData.ldapGroupsDate) {
        const checkedDate = new Date(userData.ldapGroupsDate);
        const age = new Date() - checkedDate;
        if (age > TEN_MINUTES) {
          delete userData.ldapGroups;
          delete userData.ldapGroupsDate;
          writeFileSync(userSessionFilePath, JSON.stringify(userData), "utf8");
        }
      }
    } catch (error) {
      console.log('Read session file error');
      console.log(error);
    }
  }
}
module.exports = makeSessionFile;