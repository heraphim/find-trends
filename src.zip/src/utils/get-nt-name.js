const { escape } = require('sqlstring')
const getNtName = (userDirectory, userId) => {
  return `${userDirectory.toUpperCase()}\\${userId.toUpperCase()}`;
  return `UPPER(CONCAT(${escape(userDirectory)}, CONCAT('\\', ${escape(userId)})))`
}
module.exports = getNtName;