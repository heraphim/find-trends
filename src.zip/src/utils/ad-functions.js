const findUserAD = (ad, adUser) => {
  console.log('finding');
  ad.findUser(adUser, function (adErr, user) {
    if (adErr) {
      console.log('IF ERROR: ' + JSON.stringify(adErr));
      return;
    }
    console.log('user')
    console.log(user)
    if (!user) {
      console.log('User: ' + adUser + ' not found.');
    } else {
      console.log('Success');
      console.log(user);
    }
  });
}

const authenticateUserAd = (ad, adUser, aDpass) => {
  ad.authenticate(adUser, aDpass, function (err, auth) {
    if (err) {
      console.log('ERROR: ' + JSON.stringify(err));
      return;
    }

    if (auth) {
      console.log('Authenticated!');
      console.log(auth);
    }
    else {
      console.log('Authentication failed!');
    }
  });
}

module.exports = {
  findUserAD,
  authenticateUserAd
}