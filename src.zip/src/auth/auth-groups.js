const { bqConfigSa, dbConfigSa } = require('../config/db-config');
const { format } = require('sqlstring');
const oracledb = require('oracledb');
const { BigQuery } = require('@google-cloud/bigquery');

const getCommentGroupsBQ = async (table, ntGroups, ntname, v3, bigquery) => {
  const bqProjectId = bqConfigSa.projectId;
  const bqDataset = table === 'mpr' ? bqConfigSa.dataset_mpr : bqConfigSa.dataset;
  const bqTable = table === 'mpr' ? bqConfigSa.table_mpr : (table === 'c3' ? bqConfigSa.table_c3 : bqConfigSa.table_c4);
  const tableName = `${bqProjectId}.${bqDataset}.${bqTable}`;
  let sqlQuery = `SELECT DISTINCT(COMM_GROUP)`;
  sqlQuery += table !== 'mpr' ? ', APPLICATION\n' : '\n';
  sqlQuery += `FROM ${tableName}\n`;
  if (table === 'c3') {
    sqlQuery += `WHERE UPPER(NTGROUP) IN (${ntGroups.map((ntGroup) => `'${ntGroup.replace("'", '`')}'`).join(',')})`;
  } else {
    sqlQuery += `WHERE UPPER(USERID) = '${ntname.replace('\\', '\\\\')}'`;
  }
  sqlQuery += ` AND COMM_GROUP IS NOT NULL `;
  sqlQuery += table !== 'mpr' ? 'AND APPLICATION IS NOT NULL' : '';
  sqlQuery = format(sqlQuery);
  const qoptions = { query: sqlQuery };
  let rows;
  try {
    let [rws] = await bigquery.query(qoptions);
    rows = rws;
  } catch (e) {
    console.log('getCommentGroupsBQ database error2:');
    console.log(e);
    console.log(sqlQuery);
    throw new Error(e);
  }
  return v3 ? { table, results: rows } : rows;
}

const getCommentGroups = async (table, ntGroups, ntname, v3) => {
  return getCommentGroupsBQ(table, ntGroups, ntname, v3);
  let tableName = dbConfigSa.tableName[table];
  let oracleConnection;
  try {
    oracleConnection = await oracledb.getConnection(dbConfigSa);
  } catch (err) {
    console.log("getCommentGroups oracle connection error");
    console.log(err);
    throw new Error("getCommentGroups oracle connection error");
  }
  let sql = `SELECT DISTINCT(COMM_GROUP)`;
  sql += table !== 'mpr' ? ', APPLICATION\n' : '\n';
  sql += `FROM ${tableName}\n`;
  if (table === 'c3') {
    sql += `WHERE UPPER(NTGROUP) IN (${ntGroups.map((ntGroup) => `'${ntGroup.replace("'", '`')}'`).join(',')})`;
  } else {
    sql += `WHERE UPPER(USERID) = '${ntname}'`;
  }
  sql += ` AND COMM_GROUP IS NOT NULL `;
  sql += table !== 'mpr' ? 'AND APPLICATION IS NOT NULL' : '';
  let result;
  try {
    result = await oracleConnection.execute(sql, {}, { outFormat: oracledb.OBJECT });
  } catch (err) {
    console.log("getCommentGroups oracle execute error");
    console.log(err);
    console.log(sql);
    throw new Error("getCommentGroups oracle execute error");
  }
  return v3 ? { table, results: result.rows } : result.rows;
}

const authGroups = async (ntGroups, ntname, specificTable, v3) => {
  const options = {
    keyFilename: bqConfigSa.keyFilename,
    projectId: bqConfigSa.projectId,
  };
  const bigquery = new BigQuery(options);
  const tables = specificTable ? [specificTable] : ['c3', 'c4', 'mpr'];
  const queries = tables.map((table) => getCommentGroupsBQ(table, ntGroups, ntname, v3, bigquery));
  const results = await Promise.all(queries);
  let groups;
  if (v3) {
    groups = results.reduce((result, { table, results }) => {
      const apps = results.reduce((result, { APPLICATION, COMM_GROUP }) => {
        const app = APPLICATION || 'mpr';
        const arr = result[app] || (result[app] = []);
        arr.push(COMM_GROUP);
        return result;
      }, {})
      result[table] = apps;
      return result;
    }, {})
  } else if (specificTable) {
    groups = results.flat(100).map(({ COMM_GROUP }) => COMM_GROUP);
  } else {
    const rows = results.flat(100);
    groups = rows.reduce((result, { APPLICATION, COMM_GROUP }) => {
      const app = APPLICATION || 'mpr';
      const arr = result[app] || (result[app] = []);
      arr.push(COMM_GROUP);
      return result;
    }, {})
  }

  return groups;
}

module.exports = authGroups;
