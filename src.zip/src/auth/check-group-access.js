/* global process */
const oracledb = require('oracledb');
const { format } = require('sqlstring');
const { bqConfigSa, dbConfigSa } = require('../config/db-config');
const { BigQuery } = require('@google-cloud/bigquery');
const ENV = process.env.ENV;
const checkGroupAccess = async (ntGroups, application, groups, groupType, table) => {
  if (ENV === 'local') {
    return true;
  }
  if (groupType === 'group') {
    let count;
    try {
      count = await belongsToGroup(ntGroups, application, groups, table);
      return !!count;
    } catch (error) {
      console.log('checkGroupAccess error:');
      console.log(error);
      throw new Error(error);
    }
  } else {
    return true;
  }
}

const belongsToGroupBQ = async (ntGroups, application, groups, table) => {
  const options = {
    keyFilename: bqConfigSa.keyFilename,
    projectId: bqConfigSa.projectId,
  };
  const bqProjectId = bqConfigSa.projectId;
  const bqDataset = table === 'mpr' ? bqConfigSa.dataset_mpr : bqConfigSa.dataset;
  const bqTable = table === 'mpr' ? bqConfigSa.table_mpr : (table === 'c3' ? bqConfigSa.table_c3 : bqConfigSa.table_c4);

  const bigquery = new BigQuery(options);
  const tableName = `${bqProjectId}.${bqDataset}.${bqTable}`;
  groups = Array.isArray(groups) ? groups : [groups];
  let sqlQuery = `SELECT COMM_GROUP FROM ${tableName}\n`;
  if (!Array.isArray(ntGroups)) {
    sqlQuery += `WHERE UPPER(USERID) = '${ntGroups.replace('\\', '\\\\')}'\n`;
  }
  if (table === 'c3') {
    sqlQuery += `WHERE UPPER(NTGROUP) IN (${ntGroups.map((ntGroup) => `'${ntGroup.replace("'", '`')}'`).join(',')})\n`;
  }
  sqlQuery += `AND COMM_GROUP IN (${groups.map((group) => `'${group}'`).join(',')})`;
  sqlQuery += table !== 'mpr' ? ` AND APPLICATION = '${application}'` : ``;
  sqlQuery = format(sqlQuery);

  const qoptions = { query: sqlQuery };
  let belongs, count, includes;
  try {
    let [rows] = await bigquery.query(qoptions);
    rows = rows.map(r => r.COMM_GROUP);
    count = rows.length;
    includes = groups.every((group) => rows.includes(group));
    belongs = count;
  } catch (e) {
    console.log('belongsToGroup database error2:');
    console.log(e);
    console.log(sqlQuery);
    throw new Error(e);
  }
  if (!includes || count < 1) { // TODO something is fishy
    return false;
  }
  return belongs;
}

const belongsToGroup = async (ntGroups, application, groups, table) => {
  return belongsToGroupBQ(ntGroups, application, groups, table);
  let connection;
  let tableName = dbConfigSa.tableName[table];
  try {
    connection = await oracledb.getConnection(dbConfigSa);
  } catch (e) {
    console.log('belongsToGroup database error');
    console.log(e);
    throw new Error(e);
  }
  if (!connection) {
    console.log('Database connection error:');
  }
  groups = Array.isArray(groups) ? groups : [groups];
  let sql = `SELECT COMM_GROUP FROM ${tableName}\n`;
  if (!Array.isArray(ntGroups)) {
    sql += `WHERE UPPER(USERID) = '${ntGroups}'\n`;
  }
  if (table === 'c3') {
    sql += `WHERE UPPER(NTGROUP) IN (${ntGroups.map((ntGroup) => `'${ntGroup.replace("'", '`')}'`).join(',')})\n`;
  }
  sql += `AND COMM_GROUP IN (${groups.map((group) => `'${group}'`).join(',')})`;
  sql += table !== 'mpr' ? ` AND APPLICATION = '${application}'` : ``;
  sql = format(sql);
  let belongs;
  let result;
  let count;
  let rows;
  let includes;
  try {
    result = await connection.execute(sql);
    count = result.rows.length;
    rows = result.rows.flat(100);
    includes = groups.every((group) => rows.includes(group));
    belongs = count;
  } catch (e) {
    console.log('belongsToGroup database error2:');
    console.log(e);
    console.log(sql);
    throw new Error(e);
  }
  if (!includes || count < 1) { // TODO something is fishy
    return false;
  }
  return belongs;
}


module.exports = checkGroupAccess;