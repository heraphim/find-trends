/* global process */
const { readFileSync, writeFileSync, existsSync } = require('fs');
const md5 = require('md5');
const { dummyCheckAuth } = require('../utils/');

const SESSIONS_PATH = process.env.SESSIONS_PATH;
const ENV = process.env.ENV;

const getGroups = async (activeDirectory, userId) => {
  const userSessionFilePath = SESSIONS_PATH + '/' + md5(userId) + '.json';
  if (existsSync(userSessionFilePath)) {
    const sessionFile = readFileSync(userSessionFilePath, 'utf8');
    const userData = JSON.parse(sessionFile);
    if (userData.ldapGroups) {
      return userData.ldapGroups;
    }
  }
  if (ENV === 'local') {
    return dummyCheckAuth.ldapGroups;
  } else {
    try {
      let userGroups = await activeDirectory.getGroupMembershipForUser(userId);
      userGroups = userGroups ? userGroups.map(obj => obj.cn) : [];
      const data = JSON.stringify({ ldapGroups: userGroups, ldapGroupsDate: new Date() }, null, 2);
      writeFileSync(userSessionFilePath, data, "utf8");
      return userGroups;
    } catch (error) {
      console.log('Active directory membership error');
      console.log(error);
      throw new Error("Active directory membership error");
    }
  }
}
module.exports = getGroups;