const authGroupsMPR = require('./auth-groups-mpr');
const authGroups = require('./auth-groups');
const checkQlikAuth = require('./auth');
const checkGroupAccess = require('./check-group-access');
const getGroups = require('./get-groups');
const getUser = require('./get-user');

module.exports = {
  authGroupsMPR,
  authGroups,
  checkQlikAuth,
  checkGroupAccess,
  getGroups,
  getUser,
}