/* global process */
const { dummyCheckAuth } = require('../utils/');

const getUser = async (activeDirectory, username) => {
  if (process.env.ENV === 'local') {
    return dummyCheckAuth.ldapUser;
  }
  try {
    const user = activeDirectory.findUser(username);
    if (!user) {
      console.log("Active directory user not found");
      throw new Error("Active directory user not found");
    }
    return user;
  } catch (error) {
    console.log("Active directory user code error");
    console.log(error);
    throw new Error("Active directory user code error");
  }
}

module.exports = getUser;
