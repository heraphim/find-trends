const { bqConfigSa, dbConfigSa } = require('../config/db-config');
const { format } = require('sqlstring');
const oracledb = require('oracledb');
const { BigQuery } = require('@google-cloud/bigquery');

const authGroupsMPRBQ = async (ntname) => {
  const options = {
    keyFilename: bqConfigSa.keyFilename,
    projectId: bqConfigSa.projectId,
  };
  const bqProjectId = bqConfigSa.projectId;
  const bqTable = bqConfigSa.table_mpr;
  const bqDataset = bqConfigSa.dataset_mpr;
  const tableName = `${bqProjectId}.${bqDataset}.${bqTable}`;
  const bigquery = new BigQuery(options);
  let sqlQuery = `SELECT DISTINCT(COMM_GROUP)
    FROM ${tableName}
    WHERE UPPER(USERID) = '${ntname.replace('\\', '\\\\')}'
    AND COMM_GROUP IS NOT NULL`;
  sqlQuery = format(sqlQuery);
  const qoptions = { query: sqlQuery };
  let commentGroups = [];
  try {
    let [rws] = await bigquery.query(qoptions);
    if (rws) {
      commentGroups = rws.map(({ COMM_GROUP }) => COMM_GROUP);
    }
  } catch (e) {
    console.log('authGroupsMPRBQ database error2:');
    console.log(e);
    console.log(sqlQuery);
    throw new Error(e);
  }
  return commentGroups;
}

const authGroupsMPR = async (ntname) => {
  return authGroupsMPRBQ(ntname);
  let tableName = dbConfigSa.tableName['mpr'];
  let oracleConnection;
  try {
    oracleConnection = await oracledb.getConnection(dbConfigSa);
  } catch (err) {
    console.log("authGroupsMPR oracle connection error");
    console.log(err);
    throw new Error("authGroupsMPR oracle connection error");
  }
  const sql = `SELECT DISTINCT(COMM_GROUP)
    FROM ${tableName}
    WHERE UPPER(USERID) = '${ntname}'
    AND COMM_GROUP IS NOT NULL`;
  let commentGroups = [];
  try {
    const result = await oracleConnection.execute(sql, {}, { outFormat: oracledb.OBJECT });
    if (result.rows) {
      commentGroups = result.rows.map(({ COMM_GROUP }) => COMM_GROUP);
    }
  } catch (error) {
    console.log("authGroupsMPR oracle execute error");
    console.log(error);
    console.log(sql);
    throw new Error("authGroupsMPR oracle execute error");
  }
  return commentGroups;
}

module.exports = authGroupsMPR;
