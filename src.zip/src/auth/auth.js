/* global process */
const { makeSessionFile, dummyQlikUser, isJson } = require('../utils/');
const https = require('https');
const ENV = process.env.ENV;
const QLIK_COOKIE = process.env.QLIK_COOKIE;
const QLIK_URL = process.env.QLIK_URL;
const QLIK_PATH = process.env.QLIK_PATH;

const getPrefix = (cookieStr) => {
  if (cookieStr.indexOf('-Mobile') !== -1) {
    return '/mobile'
  } if (cookieStr.indexOf('-azure') !== -1) {
    return '/azure'
  } else if (cookieStr.indexOf('-PERF-TEST') !== -1) {
    return '/perftest'
  }

  return ''
}

const getQlik = async (opts) => {
  return new Promise((resolve, reject) => {
    let req = https.request(opts, function (res) {
      // reject on bad status
      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error('Qlik auth server error'));
      }
      let data = '';
      res.on('data', chunk => { data += chunk });
      // resolve on end
      res.on('end', function () {
        let parsed;
        try {
          parsed = JSON.parse(data);
        } catch (e) {
          reject(new Error('Qlik response is not json'));
        }
        resolve(parsed);
      });
    });
    // reject on request error
    req.on('error', function (err) {
      // This is not a "Second reject", just a different sort of failure
      reject(err);
    });
    req.end();
  })
}

const checkQlikAuth = async (req, res, next) => { //req, res, next
  let cookieStr = '';
  if (req.cookies[QLIK_COOKIE]) {
    cookieStr = QLIK_COOKIE + '=' + req.cookies[QLIK_COOKIE];
  } else {
    cookieStr = "X-Qlik-Session-azure=" + req.cookies["X-Qlik-Session-azure"]
  }
  let payload;
  if (ENV === 'local') {
    payload = dummyQlikUser;
  } else {
    try {
      const opts = {
        hostname: QLIK_URL,
        path: getPrefix(cookieStr) + QLIK_PATH,
        method: 'GET',
        headers: { 'Cookie': cookieStr }
      };
      let response
      try {
        response = await getQlik(opts);
      } catch (e) {
        console.log(e);
        res.status(503);
        res.send(e);
        return;
      }
      payload = response;
      if (!response || !response?.userId) {
        console.log('Qlik auth error: unknown session');
        res.status(503);
        res.send('Qlik auth error: unknown session');
        return;
      }
      //   const qlikUrl = QLIK_URL + getPrefix(cookieStr) + QLIK_PATH;
      //   const opts = {
      //     headers: {
      //       cookie: cookieStr
      //     }
      //   };

      //   let response = await fetch(qlikUrl, opts);
      //   response = await response.json();
      //   payload = response;
    } catch (error) {
      console.log('Qlik auth error: ' + error.message);
      res.status(503);
      res.send('Qlik auth error: ' + error.message);
      return;
    }
  }
  console.log('Qlik user: ' + payload.userId);
  res.locals.qlikBody = payload;
  makeSessionFile(payload.userId);
  next();
}

module.exports = checkQlikAuth;