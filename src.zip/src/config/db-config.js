/* global process */
const bqConfigSa = {
  keyFilename: process.env.GCLOUD_KEY_FILE,
  projectId: process.env.GCLOUD_PROJECT_ID,
  dataset: process.env.GCLOUD_DATASET,
  dataset_mpr: process.env.GCLOUD_DATASET_MPR,
  table_c3: process.env.GCLOUD_TABLE_C3,
  table_c4: process.env.GCLOUD_TABLE_C4,
  table_mpr: process.env.GCLOUD_TABLE_MPR
}
const dbConfigSa = {
  user: process.env.DB_USER_SA,
  password: process.env.DB_PASS_SA,
  connectString: process.env.DB_URL_SA,
  tableName: {
    c3: process.env.DB_TABLE_ACCESS_C3,
    c4: process.env.DB_TABLE_ACCESS_C4,
    mpr: process.env.DB_TABLE_ACCESS_MPR
  }
};
const dbConfigComments = {
  user: process.env.DB_USER_COMMMENTS,
  password: process.env.DB_PASS_COMMMENTS,
  connectString: process.env.DB_URL_COMMMENTS,
  tableName: {
    c3: process.env.DB_TABLE_COMM_C3,
    c4: process.env.DB_TABLE_COMM_C4,
    mpr: process.env.DB_TABLE_COMM_MPR
  }
};

module.exports = {
  bqConfigSa,
  dbConfigSa,
  dbConfigComments
};