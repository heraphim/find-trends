/* global process */
const express = require('express');
const router = express.Router();
const multer = require('multer');
const { checkAuthComments, getComments, editComment, postComments, deleteComment } = require('../controllers/comments');
const { getImage, getFile } = require('../controllers/files');
const { resolve, extname } = require('path');
const md5 = require('md5');
const { getGroups, getUser } = require('../auth');
const { BigQuery } = require('@google-cloud/bigquery');
const ActiveDirectory = require('activedirectory2').promiseWrapper;

const config = {
  url: process.env.AD_PROTOCOL + process.env.AD_URL,
  baseDN: process.env.AD_BASEDN,
  username: process.env.AD_USER,
  password: process.env.AD_PASS
}

var ad = new ActiveDirectory(config);

const storage = multer.diskStorage({
  destination: (req, file, done) => {
    const destString = resolve(process.env.WRITEBACK, 'uploads/');
    done(null, destString);
  },
  filename: (req, file, done) => {
    const nameString = createNameForImage(file.originalname);
    done(null, nameString);
  }
});

const imageUploader = multer({
  storage: storage,
  fileFilter: (req, file, done) => {
    const allowedFileType = /jpeg|jpg|png|pdf|gif/;
    const extVal = allowedFileType.test(extname(file.originalname).toLowerCase());
    const mimeTypes = allowedFileType.test(file.mimetype);
    if (extVal && mimeTypes) {
      return done(null, true);
    } else {
      done('Error: Unacceptable File');
    }
  }
});

const createNameForImage = (imageName) => {
  imageName = imageName.trim();
  const [imgName, imgExt] = imageName.split(/(?:\.([^.]+))?$/);
  return `${md5(imgName)}-${Date.now()}.${imgExt}`;
}

router.get('/check-auth-comments', checkAuthComments);
router.get('/check-user-groups', async (req, res) => {
  try {
    const ldapUser = await getUser(ad, req.query.user);
    const ldapGroups = await getGroups(ad, req.query.user);
    res.status(200);
    res.send({ ldapUser, ldapGroups });
  } catch (err) {
    console.log(err.message);
    res.status(503);
    res.send('Error checking user: ' + err.message);
    return;
  }
});

router.get('/check-app-groups', async (req, res) => {
  const options = {
    keyFilename: 'gcloud-sa.json',
    projectId: 'vf-grp-ngbi-pprd-svcs-01',
  };
  const bigquery = new BigQuery(options);
  // const [tables] = await bigquery.dataset('IVSA_PPRD_WRITEBACK').getTables();
  // res.status(200);
  // res.send(tables);
  const sqlQuery = `SELECT * FROM \`vf-grp-ngbi-pprd-svcs-01.IVSA_PPRD_WRITEBACK.SECTION_ACCESS_C3\`  LIMIT 10000`;

  const qoptions = {
    query: sqlQuery,
    // Location must match that of the dataset(s) referenced in the query.
    // location: 'US',
  };
  const [rows] = await bigquery.query(qoptions);
  res.status(200);
  res.send(rows);
});

//comments
router.get('/get-comments', getComments);
router.patch('/edit-comment', imageUploader.fields([{ name: 'myImage', maxCount: 1 }, { name: 'myFile', maxCount: 1 }]), editComment);
router.post('/post-comments', imageUploader.fields([{ name: 'myImage', maxCount: 1 }, { name: 'myFile', maxCount: 1 }]), postComments);
router.delete('/delete-comment', deleteComment)

//selections
// router.get('/get-selection', getSelection);
// router.post('/post-selection', postSelection);
// router.patch('/edit-selection', editSelection);
// router.delete('/delete-selection', deleteSelection);


// files
router.get('/get-image', getImage);
router.get('/get-file', getFile);
// router.get('/migrate-permissions', migratePermissions);




module.exports = router;