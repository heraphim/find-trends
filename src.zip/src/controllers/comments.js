/* global process */
const ActiveDirectory = require('activedirectory2').promiseWrapper;
const { existsSync, renameSync } = require('fs');
const { format, raw } = require('sqlstring');
const { join, resolve } = require('path');
const oracledb = require('oracledb');

const { authGroupsMPR, authGroups, checkGroupAccess, getGroups, getUser } = require('../auth');
const { isObject, isJson, escapejson, getNtName, determineSecurity, c3OrC4, sqlGroups, handleGroups, sqlDelCommentGroupProcedure, sqlEditCommentProcedure } = require('../utils/');
const { getCommentSchema, postCommentSchema, editCommentSchema, deleteCommentSchema } = require('../schemas/comment-schemas');
const { dbConfigComments } = require('../config/db-config');

oracledb.fetchAsString = [oracledb.CLOB];

const config = {
  url: process.env.AD_PROTOCOL + process.env.AD_URL,
  baseDN: process.env.AD_BASEDN,
  username: process.env.AD_USER,
  password: process.env.AD_PASS
}

var ad = new ActiveDirectory(config);

const editComment = async (req, res) => {
  let { data } = isObject(req.body.data) ? req.body : JSON.parse(req.body.data)
  const files = req.files
  const errors = editCommentSchema.validate(data);
  if (errors.length) {
    console.log('postComments validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('postComments validate error');
    return;
  }
  const { application, commentary, id, v3, isReply, comment_group: commentGroup, comment_groups: commentGroups, comment_type: commentType } = data
  const { userDirectory, userId } = res.locals.qlikBody;
  let ntname = getNtName(userDirectory, userId)
  const ldapGroups = await getGroups(ad, userId);
  const security = determineSecurity(data.security);
  let commentaryField = commentary;
  if (data.commentary.indexOf('[object Object]') > -1) {
    commentaryField = JSON.stringify(commentaryField)
  }
  if (security === 'c3') {
    ntname = ldapGroups;
  }
  try {
    if ((!v3 && commentGroups) || (!v3 && files)) {
      throw new Error('Invalid V2 Structure (comment groups or image was spotted)');
    } else if (v3 && commentGroup) {
      throw new Error('Invalid V3 Structure (use "comment_groups" or remove "v3" flag)');
    }
  } catch (e) {
    console.log(e.message);
    res.status(503);
    res.send('editComment validate error: ' + e.message);
    return;
  }
  if (v3) {
    const commentAuthed = await checkGroupAccess(ntname, application, v3 ? commentGroups : commentGroup, commentType, security);
    if (!commentAuthed) {
      if (!commentAuthed) {
        console.log('Not authorized after checkGroupAccess');
        res.status(401);
        res.send('Not authorized after checkGroupAccess');
        return;
      }
    }
    ntname = getNtName(userDirectory, userId);
    if (typeof files !== 'undefined') {
      if (typeof files['myFile'] !== 'undefined') {
        commentaryField = files['myFile'][0].path.replace(resolve(process.env.WRITEBACK), '');
      }
      if (typeof files['myImage'] !== 'undefined') {
        commentaryField = files['myImage'][0].path.replace(resolve(process.env.WRITEBACK), '');
      }
      data.commentary = commentaryField;
    }
  }
  let connection;
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (e) {
    console.log('Database editComment connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  let tableName = dbConfigComments.tableName[security];
  ntname = getNtName(userDirectory, userId);
  let usersGroups = await authGroups(ldapGroups, ntname, security);
  const sqlCheck = `SELECT * FROM ${tableName}
    LEFT JOIN COMMENTS_TO_GROUPS ON ${tableName}.ID = COMMENTS_TO_GROUPS.COMMENT_ID
    RIGHT JOIN COMMENT_GROUPS ON COMMENTS_TO_GROUPS.GROUP_ID = COMMENT_GROUPS.ID
    WHERE ${tableName}.ID = :id
    AND (
      (COMMENT_GROUPS.NAME IN ('${usersGroups.join(`','`)}') AND ${tableName}.COMMENT_TYPE = 'group')
      OR
      (${tableName}.NTNAME = :ntname AND ${tableName}.COMMENT_TYPE = 'private')
    )
    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY`;
  let result;
  try {
    result = await connection.execute(sqlCheck, { id: Number(id), ntname: ntname }, { outFormat: oracledb.OBJECT });
    if (!result || result.rows.length !== 1) {
      console.log('Comment ' + id + ' not found');
      res.status(404);
      res.send('Comment ' + id + ' not found');
      return;
    }
  } catch (e) {
    console.log('Database editComment execute error:');
    console.log(e);
    console.log(sqlCheck);
    res.status(503);
    res.send(e.message);
    return;
  }
  const [row] = result.rows
  const checkNTNAME = (commentaryField || commentType || row.COMMENT_TYPE) === 'private' ? `AND NTNAME = :ntname` : '/* :ntname */'
  if (typeof files !== 'undefined' || row.COMMENTARY.indexOf('uploads') !== -1) {
    const uploadPath = row.COMMENTARY.replace('/uploads/', '/uploads/arhive/');
    const newFilePath = join(process.env.WRITEBACK, '.', uploadPath);
    const oldFilePath = join(process.env.WRITEBACK, '.', row.COMMENTARY);
    if (existsSync(oldFilePath)) {
      renameSync(oldFilePath, newFilePath);
    } else {
      console.log('File does not exist');
    }
  }
  let tempLob = await connection.createLob(oracledb.CLOB);
  await tempLob.write(commentaryField);
  let updateSql = `UPDATE ${tableName}
      SET
      COMMENTARY = :tempLob,
      COMMENT_TYPE = :commentType,
      MODIFIED_NTNAME = :ntname,
      MODIFIED_DATETIME = SYSTIMESTAMP
      WHERE ID = :id
      ${isReply ? checkNTNAME : '/* */'}`;
  let updateResult;
  try {
    updateResult = await connection.execute(updateSql, { id: Number(id), tempLob: tempLob, commentType: typeof commentType === 'undefined' ? row.COMMENT_TYPE : commentType, ntname: typeof ntname === 'undefined' ? row.MODIFIED_NTNAME : ntname }, { autoCommit: true });
  } catch (e) {
    console.log('Database editComment updateResult execute error: ');
    console.log(e);
    console.log(updateSql);
    res.status(503);
    res.send(e.message);
    return;
  }
  if (!updateResult || updateResult.rowsAffected === 0) {
    console.log('Comment does not exist:');
    res.status(404);
    res.send('Comment does not exist:');
    return;
  }
  if (!v3 || !commentGroups) {
    res.status(204);
    res.send({
      result
    });
    return;
  }
  let sqlEditCommentResult;
  try {
    sqlEditCommentResult = connection.execute(sqlEditCommentProcedure[c3OrC4(security)], { v_commentid: Number(id), v_security: security, v_commentgroup: { dir: oracledb.BIND_OUT, type: oracledb.STRING } });
  } catch (e) {
    console.log('Database editComment sqlEditCommentProcedure execute error: ');
    console.log(e);
    console.log(sqlEditCommentResult);
    res.status(503);
    res.send(e.message);
    return;
  }
  let currentGroups
  if (!sqlEditCommentResult.outBinds?.v_commentgroup === null) {
    currentGroups = [...sqlEditCommentResult.outBinds.v_commentgroup.split(',').map((group) => group.trim()), ...commentGroups]
  } else {
    currentGroups = [...commentGroups]
  }
  if (security === 'c3') {
    ntname = await getGroups(ad, userId)
  }
  const commentAuthed = await checkGroupAccess(ntname, application, currentGroups, commentType, security);
  if (!commentAuthed) {
    console.log('Not authorized after checkGroupAccess');
    res.status(401);
    res.send('Not authorized after checkGroupAccess');
    return;
  }

  try {
    await connection.execute(sqlDelCommentGroupProcedure, { vrel_commentid: Number(id), vrel_security: security }, { autoCommit: true });
  } catch (e) {
    console.log('Database editComment sqlDelCommentGroupProcedure execute error: ');
    console.log(e);
    console.log(sqlDelCommentGroupProcedure);
    res.status(503);
    res.send(e.message);
    return;
  }

  try {
    await handleGroups(id, currentGroups, security, connection);
    let result = data
    if (isJson(escapejson(result.commentary))) {
      result.commentary = JSON.parse(result.commentary)
    } else {
      result.commentary = commentaryField
    }
    res.status(200);
    res.send(result);
    return;
  } catch (error) {
    console.log('Comment and groups update error:');
    console.log(error);
    res.status(503);
    res.send(error.message);
    return;
  }
}

const postComments = async (req, res) => {
  let commentary = req.body.data.commentary;
  const { userDirectory, userId } = res.locals.qlikBody
  let { data } = isObject(req.body.data) ? req.body : JSON.parse(req.body.data);
  const files = req.files
  let groups = ['private']

  const errors = postCommentSchema.validate(data);
  if (errors.length) {
    console.log('postComments validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('postComments validate error');
    return;
  }
  try {
    if (!data.comment_group && (!data.comment_groups || (Array.isArray(data.comment_groups) && data.comment_groups.length === 0))) {
      throw new Error('comment_group or comment_groups needed');
    }
    if ((!data.v3 && data.comment_groups) || (!data.v3 && files)) {
      throw new Error('Invalid V2 Structure (comment groups or image was spotted)');
    } else if (data.v3 && data.comment_group) {
      throw new Error('Invalid V3 Structure (use "comment_groups" or remove "v3" flag)');
    }
  } catch (e) {
    console.log(e.message);
    res.status(503);
    res.send('postComments validate error: ' + e.message);
    return;
  }

  const security = determineSecurity(data.security);
  let ntname = security === 'c3' ? await getGroups(ad, userId) : getNtName(userDirectory, userId);
  const commentAuthed = await checkGroupAccess(ntname, data.application, data.v3 ? data.comment_groups : data.comment_group, data.comment_type, security)
  if (!commentAuthed) {
    if (!commentAuthed) {
      console.log('Not authorized after checkGroupAccess');
      res.status(401);
      res.send('Not authorized after checkGroupAccess');
      return;
    }
  }
  ntname = getNtName(userDirectory, userId);
  if (data.v3) {
    groups = data.comment_groups;
    if (typeof files !== 'undefined') {
      if (typeof files['myFile'] !== 'undefined') {
        commentary = files['myFile'][0].path.replace(resolve(process.env.WRITEBACK), '');
      }
      if (typeof files['myImage'] !== 'undefined') {
        commentary = files['myImage'][0].path.replace(resolve(process.env.WRITEBACK), '');
      }
      data.commentary = commentary
    }
  } else if (data.comment_group) {
    groups = [data.comment_group]
  }

  if (!data.commentary) {
    console.log('postComments validate error: please enter commentary');
    res.status(503);
    res.send('postComments validate error: please enter commentary');
    return;
  }
  let connection;
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (e) {
    console.log('Database connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  const secFlag = c3OrC4(security);
  let sql;
  const { application, approved, sheet, current_selections, comment_location, comment_type } = data;
  const commentaryToSave = data.commentary;
  sql = `BEGIN inscomment_${secFlag} (:application, :approved, :comment_location, :comment_type, :commentaryToSave, :current_selections, :sheet, :ntname, :v_commentid); END;`;
  let result;
  try {
    result = await connection.execute(sql,
      {
        application: application,
        approved: approved,
        comment_location: comment_location,
        comment_type: comment_type,
        commentaryToSave: commentaryToSave,
        current_selections: current_selections,
        sheet: sheet,
        ntname: ntname,
        v_commentid: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }, { autoCommit: true }
    );

    const commentId = result.outBinds.v_commentid;

    let dataToReturn = data;
    if (isJson(escapejson(result.commentary))) {
      dataToReturn.commentary = JSON.parse(dataToReturn.commentary);
    } else {
      dataToReturn.commentary = commentary
    }

    await handleGroups(commentId, groups, security, connection);

    res.status(201);
    res.send({
      ...dataToReturn,
      id: commentId
    });
    return;
  } catch (e) {
    console.log('Database connection error:');
    console.log(e);
    console.log(sql);
    res.status(503);
    res.send(e.message);
    return;
  }
}


const addCommentGroup = async (result, tableName, connection, security, v3, withGroups = true) => {
  if (!withGroups) {
    if (isJson(escapejson(result['COMMENTARY']))) {
      result['COMMENTARY'] = JSON.parse(escapejson(result['COMMENTARY']));
      return result;
    }
    return result;
  } else {
    try {
      const results = await connection.execute(sqlGroups(tableName), { security, id: Number(result.ID) });
      const commentGroupsFound = results.rows[0][0];
      if (v3) {
        delete result['COMMENT_GROUP']
      }
      if (commentGroupsFound) {
        result['COMMENT_GROUPS'] = commentGroupsFound.split(',').map((grp) => grp.trim())
      }
      if (isJson(escapejson(result['COMMENTARY']))) {
        result['COMMENTARY'] = JSON.parse(escapejson(result['COMMENTARY']))
      }
      return result;
    } catch (e) {
      console.log('Add comment group error');
      throw new Error(e);
    }
  }
}

const formatResults = async (results, tableName, connection, security, v3, withGroups = true) => {
  const queries = results.map((result) => addCommentGroup(result, tableName, connection, security, v3, withGroups));
  try {
    return Promise.all(queries);
  } catch (e) {
    console.log('formatResults error');
    throw new Error(e);
  }
}


const getComments = async (req, res) => {
  const errors = getCommentSchema.validate(req.query);
  if (errors.length) {
    console.log('getComments validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('getComments validate error');
    return;
  }
  const {
    application,
    ids,
    sheet,
    since,
    until,
    v3,
    page = 1,
    size = 10000,
    count_distinct: countDistinct,
    comment_group: commentGroup,
    comment_location: commentLocation,
    comment_locations: commentLocations,
    comment_type: commentType,
    current_selections: currentSelections,
    order_by: orderBy = 'asc'
  } = req.query

  const { userDirectory, userId } = res.locals.qlikBody;

  let ntname = getNtName(userDirectory, userId)
  const security = determineSecurity(req.query.security);
  let ldapGroups = security !== 'c3' ? ntname : await getGroups(ad, userId);
  let commentAuthed;
  try {
    commentAuthed = await checkGroupAccess(ldapGroups, application, commentGroup, commentType, security);
  } catch (e) {
    console.log('checkGroupAccess getComments error');
    console.log(e.message);
    res.status(503);
    res.send(e.message);
    return;
  }
  if (!commentAuthed) {
    console.log('Not authorized after checkGroupAccess');
    res.status(401);
    res.send('Not authorized after checkGroupAccess');
    return;
  }

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (e) {
    console.log('Database getComments connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  const low = (page - 1) * size
  let usersGroups = await authGroups(ldapGroups, ntname, security)
  if (!commentType) {
    usersGroups.push('private')
  }
  let rowIds
  if (ids) {
    rowIds = JSON.parse(ids).map((id) => `'${id}'`).join(',')
  }
  let rowCommentLocations;
  let additionalLocations = {};
  if (commentLocations) {
    rowCommentLocations = JSON.parse(commentLocations);
    rowCommentLocations.forEach((loc, i) => {
      const [location, additional] = loc.split('+');
      if (additional) {
        if (location && additional) {
          additionalLocations[additional] = `${location}`;
        }
      }
      rowCommentLocations[i] = `'${location}'`;
    });
    rowCommentLocations = rowCommentLocations.join(',');
  }
  let sql;
  let tableName = dbConfigComments.tableName[security];
  if (countDistinct) {
    sql = format(`
      SELECT COUNT(*) COUNT, ${countDistinct}
      FROM ${tableName}
      WHERE APPLICATION = ?
      ${sheet !== 'all' ? `AND ${tableName}.SHEET = ?` : `/* ? */`}
      AND (NTNAME = '${ntname}' AND COMMENT_TYPE = 'private')
      GROUP BY ${countDistinct}
    `, [application, sheet]);
  } else {
    let sqlString = `
    SELECT * FROM ${tableName}
      LEFT JOIN (
        SELECT ${tableName}.ID, ${tableName}.DATETIME, LISTAGG(COMMENT_GROUPS.NAME,', ')
        WITHIN GROUP(ORDER BY COMMENT_GROUPS.NAME) AS COMMENT_GROUP
          FROM ${tableName}
          LEFT JOIN COMMENTS_TO_GROUPS ON ${tableName}.ID = COMMENTS_TO_GROUPS.COMMENT_ID
          RIGHT JOIN COMMENT_GROUPS ON COMMENTS_TO_GROUPS.GROUP_ID = COMMENT_GROUPS.ID
          WHERE ${tableName}.APPLICATION = ?
          ${sheet !== 'all' ? `AND ${tableName}.SHEET = ?` : `/* ? */`}
          AND COMMENTS_TO_GROUPS.SECURITY = '${security}'
          ${commentType ? `AND ${tableName}.COMMENT_TYPE = ?` : '/* ? */'}
          ${commentType === 'private' ? `AND ${tableName}.NTNAME = '${ntname}'` : '/* NTNAME */'}
          ${commentLocation ? `AND ${tableName}.COMMENT_LOCATION = ?` : '/* ? */'}
          ${currentSelections ? `AND dbms_lob.compare(${tableName}.CURRENT_SELECTIONS, TO_CLOB(?)) = 0` : '/* ? */'}
          ${since ? `AND ${tableName}.DATETIME >= TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS')` : '/* ? */'}
          ${until ? `AND ${tableName}.DATETIME < TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS')` : '/* ? */'}
          ${ids ? `AND ${tableName}.ID IN (${rowIds})` : '/* ID IN () */'}
          ${rowCommentLocations ? `AND ${tableName}.COMMENT_LOCATION IN (${rowCommentLocations})` : '/* ID IN () */'}
          ${commentGroup ? `AND COMMENT_GROUPS.NAME = '${commentGroup}'` : `AND COMMENT_GROUPS.NAME IN ('${usersGroups.join(`','`)}')`}
           GROUP BY ${tableName}.ID, ${tableName}.DATETIME
           ORDER BY ${tableName}.DATETIME ?
        )
        IDS on ${tableName}.ID = IDS.ID
        WHERE IDS.ID IS NOT NULL
        AND (
          COMMENT_TYPE = 'group'
          OR
          (COMMENT_TYPE = 'private' AND NTNAME = '${ntname}')
        )
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
    `;
    sql = format(sqlString, [application, sheet, commentType, commentLocation, currentSelections, since, until, raw(orderBy.toUpperCase()), low, size])
  }
  let resultsWithGroups;
  try {
    let results = await connection.execute(sql, {}, { outFormat: oracledb.OBJECT });
    const commentResults = results.rows;
    if (!countDistinct && v3) {
      resultsWithGroups = await formatResults(commentResults, tableName, connection, security, v3, true);
    } else {
      resultsWithGroups = await formatResults(commentResults, tableName, connection, security, v3, false);
    }
  } catch (e) {
    console.log('Database execute error:');
    console.log(e);
    console.log(sql);
    res.status(503);
    res.send(e.message);
    return;
  }
  if (Object.keys(additionalLocations).length > 0) {
    let additionalLocationsList = Object.keys(additionalLocations).map(loc => `'${loc}'`).join(',');
    let additionalSqlString = `
      SELECT * FROM ${tableName}
      WHERE ${tableName}.APPLICATION = ?
      AND ${tableName}.COMMENT_LOCATION IN (${additionalLocationsList})
    `;
    let additionalSql = format(additionalSqlString, [application]);
    try {
      let additionalResults = await connection.execute(additionalSql, {}, { outFormat: oracledb.OBJECT });
      additionalResults = additionalResults.rows;
      additionalResults.forEach((addRes) => {
        let mainRowLocation = additionalLocations[addRes.COMMENT_LOCATION];
        let mainRowIndex = resultsWithGroups.findIndex(mainRes => mainRes.COMMENT_LOCATION === mainRowLocation);
        if (mainRowIndex === -1) {
          resultsWithGroups.push({
            COMMENT_LOCATION: mainRowLocation,
            ADDITIONAL_ROW: addRes
          });
        } else {
          resultsWithGroups[mainRowIndex].ADDITIONAL_ROW = addRes;
        }
      });
    } catch (e) {
      console.log('Database execute error additional results:');
      console.log(e);
      console.log(sql);
      res.status(503);
      res.send(e.message);
      return;
    }
  }

  res.status(200);
  res.send(resultsWithGroups);
  return;
}

const deleteComment = async (req, res) => {
  const errors = deleteCommentSchema.validate(req.query);
  if (errors.length) {
    console.log('deleteComment validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('deleteComment validate error');
    return;
  }
  const { id } = req.query;
  const { userDirectory, userId } = res.locals.qlikBody;
  const ntname = getNtName(userDirectory, userId)
  const ldapGroups = await getGroups(ad, userId);
  const security = determineSecurity(req.query.security);
  let usersGroups = await authGroups(ldapGroups, ntname, security);
  let connection;
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (err) {
    console.log("deleteComment oracle connection error");
    console.log(err);
    throw new Error("deleteComment oracle connection error");
  }
  let tableName = dbConfigComments.tableName[security];
  const sqlCheck = format(`
    SELECT * FROM ${tableName}
    LEFT JOIN COMMENTS_TO_GROUPS ON ${tableName}.ID = COMMENTS_TO_GROUPS.COMMENT_ID
    RIGHT JOIN COMMENT_GROUPS ON COMMENTS_TO_GROUPS.GROUP_ID = COMMENT_GROUPS.ID
    WHERE ${tableName}.ID = :id
    AND (
      (COMMENT_GROUPS.NAME IN ('${usersGroups.join(`','`)}') AND ${tableName}.COMMENT_TYPE = 'group')
      OR
      (${tableName}.NTNAME = '${ntname}' AND ${tableName}.COMMENT_TYPE = 'private')
    )
    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY`);

  try {
    const results = await connection.execute(sqlCheck, { id: Number(id) }, { outFormat: oracledb.OBJECT });
    if (!results) {
      console.log('Comment ' + id + ' not found');
      res.status(404);
      res.send('Comment ' + id + ' not found');
      return;
    } else {
      if (results.rows.length > 0) {
        const [row] = results.rows;
        const uploadPath = row.COMMENTARY.replace('/uploads/', '/uploads/arhive/');
        const newFilePath = join(process.env.WRITEBACK, '.', uploadPath);
        const oldFilePath = join(process.env.WRITEBACK, '.', row.COMMENTARY);
        if (existsSync(oldFilePath)) {
          renameSync(oldFilePath, newFilePath);
        } else {
          console.log('File does not exist');
        }
      }
    }
  } catch (e) {
    console.log('Database connection error:');
    console.log(e);
    console.log(sqlCheck);
    res.status(503);
    res.send(e.message);
    return;
  }
  const sqlDelete = format(`
    DELETE FROM ${tableName}
    WHERE ID = :id
    AND NTNAME = '${ntname}'`);
  try {
    const result = await connection.execute(sqlDelete, { id: Number(id) }, { autoCommit: true });
    console.log(result);
    if (!result || result.rowsAffected === 0) {
      console.log('Comment ' + id + ' not found');
      res.status(404);
      res.send('Comment ' + id + ' not found');
      return;
    }
  } catch (e) {
    console.log('Database connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  res.status(204);
  res.send('Comment ' + id + ' deleted!');
  return;
}

// TODO: remove comment groups as it is no longer used is the frontend
const checkAuthComments = async (req, res) => {
  const { userDirectory, userId } = res.locals.qlikBody;
  try {
    const ldapUser = await getUser(ad, userId);
    const ldapGroups = await getGroups(ad, userId);
    const ntname = getNtName(userDirectory, userId);
    const commentGroups = req.query.v2 || req.query.v3 ? await authGroups(ldapGroups, ntname, null, req.query.v3) : await authGroupsMPR(ntname)
    res.send(Object.assign(res.locals.qlikBody, { commentGroups, ldapUser, ldapGroups }));
  } catch (error) {
    console.log('checkAuthComments error');
    console.log(error);
    res.status(503);
    res.send(error.message);
  }
}

module.exports = {
  checkAuthComments,
  getComments,
  editComment,
  postComments,
  deleteComment
}