/* global process */
const { getImageSchema } = require('../schemas/files-schemas');
const oracledb = require('oracledb');
const ActiveDirectory = require('activedirectory2').promiseWrapper;
const { dbConfigComments } = require('../config/db-config');
const { authGroups, getGroups } = require('../auth');
const { isJson, escapejson, getNtName, determineSecurity } = require('../utils/');
const { join } = require('path');

oracledb.fetchAsString = [oracledb.CLOB];
const config = {
  url: process.env.AD_PROTOCOL + process.env.AD_URL,
  baseDN: process.env.AD_BASEDN,
  username: process.env.AD_USER,
  password: process.env.AD_PASS
}

var ad = new ActiveDirectory(config);

const getFile = async (req, res) => {
  const errors = getImageSchema.validate(req.query);
  if (errors.length) {
    console.log('getFile validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('getFile validate error');
    return;
  }
  const { path } = req.query;
  const { userDirectory, userId } = res.locals.qlikBody;
  const ntname = getNtName(userDirectory, userId);
  const ldapGroups = await getGroups(ad, userId);
  const security = determineSecurity(req.query.security);
  let connection;
  let tableName = dbConfigComments.tableName[security];
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (e) {
    console.log('Database getFile connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  let usersGroups = await authGroups(ldapGroups, ntname, security);
  usersGroups.push('private');
  const sql = `
    SELECT ${tableName}.* FROM ${tableName}
    LEFT JOIN COMMENTS_TO_GROUPS ON ${tableName}.ID = COMMENTS_TO_GROUPS.COMMENT_ID
    RIGHT JOIN COMMENT_GROUPS ON COMMENTS_TO_GROUPS.GROUP_ID = COMMENT_GROUPS.ID
    AND ${tableName}.COMMENTARY LIKE :v_filepath
    AND COMMENTS_TO_GROUPS.SECURITY = :v_security
    AND ${tableName}.ID IS NOT NULL
    AND (
      ${tableName}.COMMENT_TYPE = 'group'
      OR
      (${tableName}.COMMENT_TYPE = 'private' AND ${tableName}.NTNAME = '${ntname}')
    )
    AND COMMENT_GROUPS.NAME IN ('${usersGroups.join(`','`)}')`;
  let results;
  try {
    results = await connection.execute(sql, { v_filepath: `%${path}%`, v_security: security }, { outFormat: oracledb.OBJECT });
  } catch (e) {
    console.log('Database getFile execute error:');
    console.log(e);
    console.log(sql);
    res.status(503);
    res.send(e.message);
    return;
  }
  const [foundFile] = results.rows.filter(({ ID }) => !!ID)

  if (!foundFile) {
    console.log('File not found in db.');
    res.status(404);
    res.send('File not found in db.');
    return;
  }
  if (!isJson(escapejson(foundFile.COMMENTARY))) {
    const filePath = join(process.env.WRITEBACK, '.', foundFile.COMMENTARY);
    return res.sendFile(filePath);
  }

  const fileObj = JSON.parse(escapejson(foundFile.COMMENTARY));
  if (fileObj.type === 'document') {
    if (typeof fileObj.text !== 'undefined') {
      const filePath = join(process.env.WRITEBACK, '.', fileObj.text)
      return res.sendFile(filePath);
    }
    if (typeof fileObj.url !== 'undefined') {
      const filePath = join(process.env.WRITEBACK, '.', fileObj.url)
      return res.sendFile(filePath);
    }
    console.log('File not found.');
    res.status(404);
    res.send('File not found.');
    return;
  }


  // eslint-disable-next-line no-prototype-builtins
  if (!fileObj.hasOwnProperty('steps') || !Array.isArray(fileObj.steps)) {
    console.log('Incorrect request format to get file.');
    res.status(404);
    res.send('Incorrect request format to get file.');
    return;
  }
  let sent = false;
  fileObj.steps.forEach(row => {
    if (row.type === 'document') {
      if (typeof row.url !== 'undefined') {
        if (row.url === path) {
          const filePath = join(process.env.WRITEBACK, '.', row.url);
          res.sendFile(filePath);
          sent = true;
          return
        }
      }
      if (typeof row.text !== 'undefined') {
        if (row.text === path) {
          const filePath = join(process.env.WRITEBACK, '.', row.text);
          res.sendFile(filePath);
          sent = true;
          return;
        }
      }
      if (typeof row.file !== 'undefined') {
        if (row.file === path) {
          const filePath = join(process.env.WRITEBACK, '.', row.file);
          res.sendFile(filePath);
          sent = true;
          return;
        }
      }
    }
  });
  if (!sent) {
    console.log('Something went wrong.');
    res.status(404);
    res.send('Something went wrong.');
  }
  return;
}

const getImage = async (req, res) => {
  const errors = getImageSchema.validate(req.query);
  if (errors.length) {
    console.log('getImage validate error');
    errors.forEach(e => { console.log(e.message) });
    res.status(503);
    res.send('getImage validate error');
    return;
  }
  const { path } = req.query;
  const { userDirectory, userId } = res.locals.qlikBody;
  const ntname = getNtName(userDirectory, userId);
  const ldapGroups = await getGroups(ad, userId);
  const security = determineSecurity(req.query.security);
  let connection;
  let tableName = dbConfigComments.tableName[security];
  try {
    connection = await oracledb.getConnection(dbConfigComments);
  } catch (e) {
    console.log('Database getImage connection error:');
    console.log(e);
    res.status(503);
    res.send(e.message);
    return;
  }
  let usersGroups = await authGroups(ldapGroups, ntname, security);
  usersGroups.push('private');
  const sql = `
    SELECT ${tableName}.* FROM ${tableName}
    LEFT JOIN COMMENTS_TO_GROUPS ON ${tableName}.ID = COMMENTS_TO_GROUPS.COMMENT_ID
    RIGHT JOIN COMMENT_GROUPS ON COMMENTS_TO_GROUPS.GROUP_ID = COMMENT_GROUPS.ID
    AND ${tableName}.COMMENTARY LIKE :v_imagepath
    AND COMMENTS_TO_GROUPS.SECURITY = :v_security
    AND ${tableName}.ID IS NOT NULL
    AND (
      ${tableName}.COMMENT_TYPE = 'group'
      OR
      (${tableName}.COMMENT_TYPE = 'private' AND ${tableName}.NTNAME = '${ntname}')
    )
    AND COMMENT_GROUPS.NAME IN ('${usersGroups.join(`','`)}')`;
  let results;
  try {
    results = await connection.execute(sql, { v_imagepath: `%${path}%`, v_security: security }, { outFormat: oracledb.OBJECT });
  } catch (e) {
    console.log('Database getImage execute error:');
    console.log(e);
    console.log(sql);
    res.status(503);
    res.send(e.message);
    return;
  }
  const [foundImage] = results.rows.filter(({ ID }) => !!ID);
  if (!foundImage) {
    console.log('Image not found in db.');
    res.status(404);
    res.send('Image not found in db.');
    return;
  }
  if (!isJson(escapejson(foundImage.COMMENTARY))) {
    const filePath = join(process.env.WRITEBACK, '.', foundImage.COMMENTARY);
    return res.sendFile(filePath);
  }

  const imageObj = JSON.parse(escapejson(foundImage.COMMENTARY))
  if (imageObj.type === 'image') {
    if (typeof imageObj.text !== 'undefined') {
      const filePath = join(process.env.WRITEBACK, '.', imageObj.text);
      return res.sendFile(filePath);
    }
    if (typeof imageObj.url !== 'undefined') {
      const filePath = join(process.env.WRITEBACK, '.', imageObj.url);
      return res.sendFile(filePath);
    }
  } else {
    console.log('Image not found on server.');
    res.status(404);
    res.send('Image not found on server.');
    return;
  }


}


module.exports = {
  getImage,
  getFile
}