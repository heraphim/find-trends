/* global process */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require("cookie-parser");
const bodyParser = require('body-parser');
const { checkQlikAuth } = require('./auth');
const commentRoutes = require("./routes/");
const oracledb = require('oracledb');

let clientOpts = {};
oracledb.initOracleClient(clientOpts);

const app = express();
app.use(cookieParser());
app.use(bodyParser.json());
app.use(cors());

app.get('/check', (req, res) => res.send('OK'));

app.use((req, res, next) => {
  console.log('=== new request ' + (req.query?.application || req.body.data?.application || 'for ') + ' ' + req.path + ' ===');
  console.log('=== ' + (new Date().toUTCString()) + ' ===');
  next();
});

app.use('/', checkQlikAuth, commentRoutes);
const PORT = process.env.PORT || process.env.FILE_PORT;

app.listen(PORT, async (listenErr) => {
  if (listenErr) {
    console.log(listenErr);
    return;
  }
  console.log(`running server on from port:::::::${PORT}`);
});
