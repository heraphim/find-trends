const Schema = require('validate');

const getImageSchema = new Schema({
  path: {
    type: 'string',
    required: true
  },
  security: {
    type: 'string',
    match: /(c3|c4|mpr)/,
    required: true
  }
}, {
  typecast: true
});


module.exports = {
  getImageSchema
}