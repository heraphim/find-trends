const Schema = require('validate');

const editCommentSchema = new Schema({
  application: {
    type: 'string',
    required: true
  },
  commentary: {
    type: 'string',
    required: false
  },
  comment_groups: {
    type: 'array',
    required: false
  },
  comment_type: {
    type: 'string',
    match: /(private|group)/,
    required: false
  },
  security: {
    type: 'string',
    match: /(c3|c4|mpr)/,
    required: true
  },
  isReply: {
    type: 'boolean',
    required: false
  },
  id: {
    type: 'number',
    required: true
  },
  v3: {
    type: 'boolean',
    required: false
  }
}, {
  typecast: true
});

const deleteCommentSchema = new Schema({
  id: {
    type: 'number',
    required: true
  },
  security: {
    type: 'string',
    match: /(c3|c4|mpr)/,
    required: true
  }
}, {
  typecast: true
});

const postCommentSchema = new Schema({
  application: {
    type: 'string',
    required: true
  },
  approved: {
    type: 'number',
    required: false
  },
  comment_group: {
    type: 'string',
    required: false
  },
  comment_groups: {
    type: 'array',
    required: false
  },
  comment_location: {
    type: 'string',
    required: false
  },
  comment_type: {
    type: 'string',
    match: /(private|group)/,
    required: true
  },
  commentary: {
    type: 'string',
    required: false
  },
  current_selections: {
    type: 'string',
    required: true
  },
  sheet: {
    type: 'string',
    required: true
  },
  security: {
    type: 'string',
    match: /(c3|c4|mpr)/,
    required: false
  },
  v3: {
    type: 'boolean',
    required: false
  }
}, {
  typecast: true
});

const getCommentSchema = new Schema({
  application: {
    type: 'string',
    required: true
  },
  count_distinct: {
    type: 'string',
    match: /(comment_location)/,
    required: false
  },
  comment_group: {
    type: 'string',
    required: false
  },
  comment_location: {
    type: 'string',
    required: false
  },
  comment_locations: {
    type: 'string',
    required: false
  },
  comment_type: {
    type: 'string',
    match: /(private|group)/,
    required: false
  },
  current_selections: {
    type: 'string',
    required: false
  },
  ids: {
    type: 'string',
    required: false
  },
  order_by: {
    type: 'string',
    match: /(asc|desc)/,
    required: false
  },
  page: {
    type: 'number',
    required: false
  },
  security: {
    type: 'string',
    match: /(c3|c4|mpr)/,
    required: false
  },
  sheet: {
    type: 'string',
    required: true
  },
  since: {
    type: 'string',
    required: false
  },
  size: {
    type: 'number',
    required: false
  },
  until: {
    type: 'string',
    required: false
  },
  v3: {
    type: 'boolean',
    required: false
  }
}, {
  typecast: true
});

module.exports = {
  getCommentSchema,
  postCommentSchema,
  editCommentSchema,
  deleteCommentSchema
}