export NODE_TLS_REJECT_UNAUTHORIZED=0
for N in {1..4}
do
  PORT=900$N forever start -c "npm run dev" ./
done
